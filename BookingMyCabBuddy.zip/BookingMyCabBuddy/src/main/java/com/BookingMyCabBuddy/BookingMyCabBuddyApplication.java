package com.BookingMyCabBuddy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookingMyCabBuddyApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookingMyCabBuddyApplication.class, args);
	}

}
