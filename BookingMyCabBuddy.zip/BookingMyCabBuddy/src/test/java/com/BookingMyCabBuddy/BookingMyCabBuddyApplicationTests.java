package com.BookingMyCabBuddy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookingMyCabBuddyApplicationTests {

	@Test
	void contextLoads() {
	}

}
