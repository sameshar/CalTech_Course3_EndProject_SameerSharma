package com.EurekaServerMyCabBuddy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EurekaServerMyCabBuddyApplication {

	public static void main(String[] args) {
		SpringApplication.run(EurekaServerMyCabBuddyApplication.class, args);
	}

}
