package com.FareCalcuator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FareCalcuatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(FareCalcuatorApplication.class, args);
	}

}
